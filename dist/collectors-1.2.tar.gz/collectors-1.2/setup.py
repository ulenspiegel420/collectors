from setuptools import setup

setup(
    name='collectors',
    version='1.2',
    packages=['collectors'],
    url='',
    license='',
    author='Vlad Koval',
    author_email='',
    description=''
)
