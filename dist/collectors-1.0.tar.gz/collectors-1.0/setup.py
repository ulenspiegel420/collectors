from setuptools import setup

setup(
    name='collectors',
    version='1.0',
    packages=['collectors'],
    url='',
    license='',
    author='Vlad Koval',
    author_email='',
    description=''
)
